#include "AgtInfoMsg.h"

AgtInfoMsg::AgtInfoMsg(void)
{
}

AgtInfoMsg::~AgtInfoMsg(void)
{
}
