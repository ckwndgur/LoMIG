#include "AgtRscMsg.h"

AgtRscMsg::AgtRscMsg(void)
{
}

AgtRscMsg::~AgtRscMsg(void)
{
}
