#include "AgtDataMsg.h"

AgtDataMsg::AgtDataMsg(void)
{
}

AgtDataMsg::~AgtDataMsg(void)
{
}
