#include "DataReqMsg.h"

DataReqMsg::DataReqMsg(void)
{
}

DataReqMsg::~DataReqMsg(void)
{
}
